import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { AppTodoComponent } from './add-todo.component';


describe('AddTodoComponent', () => {
  let component: AppTodoComponent;
  let fixture: ComponentFixture<AppTodoComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppTodoComponent
      ]
    }).compileComponents();
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(AppTodoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
