import {Injectable} from "@angular/core";
import {Todo} from "./todo";
import {TodoStatus} from "./todo-status.enum";

@Injectable()
export class TodosService {
  getTodos():Todo[]{
    return [
      {name:'analiza interfejsu ekranu głównego', status:TodoStatus.BUG},
      {name:'analiza serwisu ttt', status:TodoStatus.TODO},
      {name:'analiza ustawień początowych', status:TodoStatus.IN_REVIEW}
    ];
  }
}
